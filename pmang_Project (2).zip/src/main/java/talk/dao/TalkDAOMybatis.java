package talk.dao;

public class TalkDAOMybatis implements TalkDAO {

}
