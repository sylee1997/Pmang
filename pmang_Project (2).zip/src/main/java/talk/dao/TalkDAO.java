package talk.dao;

public interface TalkDAO {

}
