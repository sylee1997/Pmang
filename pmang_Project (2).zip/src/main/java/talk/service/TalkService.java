package talk.service;

public interface TalkService {

}
