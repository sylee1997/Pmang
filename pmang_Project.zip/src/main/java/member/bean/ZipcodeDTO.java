package member.bean;

import lombok.Data;

@Data
public class ZipcodeDTO {
	private String zipcode;
	private String sido;
	private String sigungu;
	private String yubmyundong;
	private String ri;
	private String roadname;
	private String buildingname;




}
