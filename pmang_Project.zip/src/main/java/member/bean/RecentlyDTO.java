package member.bean;

import lombok.Data;

@Data
public class RecentlyDTO {
	private String address;
	private String userId;
}
