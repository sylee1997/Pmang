package board.dao;

import board.bean.ReviewDTO;

public interface ReviewDAO {

	void reviewWrite(ReviewDTO reviewDTO);

}
