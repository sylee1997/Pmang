package board.bean;

import lombok.Data;

@Data
public class WishlistDTO {
	private int wishlist_seq;
	private String userId;
	private int item_seq;
}
