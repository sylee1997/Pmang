package board.bean;

import lombok.Data;

@Data
public class AdminDTO {
	private int userCount;
	private int itemCount;
}
