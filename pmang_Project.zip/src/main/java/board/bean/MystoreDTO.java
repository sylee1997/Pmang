package board.bean;

public class MystoreDTO {

}
