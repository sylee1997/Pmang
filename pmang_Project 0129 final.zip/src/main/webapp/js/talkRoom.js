//socket.send(“data”); // 클라이언트에서 서버로 데이터를 보냄

//onopen //연결이 설정되면 호출하는 이벤트

//onclose //연결이 끊어지면 호출하는 이벤트

//onmessage //서버에서 데이터를 보내면 호출하는 이벤트




	function connect() {
	    sock = new SockJS('/talk');
	    
	    sock.onopen = function() { 
	        console.log('open');
	    };
	    sock.onmessage = function(evt) {
    	 var data = evt.data;
    	   console.log(data)
  		   var obj = JSON.parse(data)  	   
    	   console.log(obj)
    	   appendMessage(obj.message_content);
	    };
	    sock.onclose = function() {
	    	 appendMessage("연결을 끊었습니다.");
	        console.log('close');
	    };
	}

  function send() {
	  var msg = $("#message").val();
	  if(msg != ""){
		  message = {};
		  message.message_content = $("#message").val()
	  	  message.TUTOR_USER_user_id = '${TUTOR_USER_user_id}'
	  	  message.USER_user_id = '${profile.user_id}'
	  	  message.CLASS_class_id = '${class_id}'
	  	  message.message_sender = '${profile.user_id}'
	  }
	  
	  sock.send(JSON.stringify(message));
	  $("#message").val("");
	 }
	  
  function appendMessage(msg) {

		 if(msg == ''){
			 return false;
		 }else{


		 var t = getTimeStamp();
		 $("#chatMessageArea").append("<div class='col-12 row' style = 'height : auto; margin-top : 5px;'><div class='col-2' style = 'float:left; padding-right:0px; padding-left : 0px;'><img id='profileImg' class='img-fluid' src='/displayFile?fileName=${userImage}&directory=profile' style = 'width:50px; height:50px; '><div style='font-size:9px; clear:both;'>${user_name}</div></div><div class = 'col-10' style = 'overflow : y ; margin-top : 7px; float:right;'><div class = 'col-12' style = ' background-color:#ACF3FF; padding : 10px 5px; float:left; border-radius:10px;'><span style = 'font-size : 12px;'>"+msg+"</span></div><div col-12 style = 'font-size:9px; text-align:right; float:right;'><span style ='float:right; font-size:9px; text-align:right;' >"+t+"</span></div></div></div>")		 

		  var chatAreaHeight = $("#chatArea").height();
		  var maxScroll = $("#chatMessageArea").height() - chatAreaHeight;
		  $("#chatArea").scrollTop(maxScroll);

		 }
	 }


  $(document).ready(function() {
	  connect();//ready 시작에서 실행해줄것.
	   
	   $('#test').on('click', (function() {
		   
	      var messageContent = ('메세지내용이 들어감');
	      
	      var talkDate = '오늘날짜가들어감';
	      var profileImg = '이미지주소가 들어감';
	      var talkTime= '시간이들어감';
	      var talkRead= '안읽음';
	      
	      
	      //상단날짜div
	      var talkDateDiv = $('<div />', {
	         class: 'talkDateDiv'
	      });
	      //상단날짜 들어가는 div
	      var talkDate = $('<div />', {
	         class: 'talkDate',
	         align: 'center',
	         text: talkDate
	      });
	      
	      //받은메세지
	      var talkReciveDiv = $('<div />',{
	         class: 'talkReciveDiv'
	      });
	      //받은 메세지 말풍선+내용
	      var talkReciveTooltip = $('<div />', {
	         class: 'talkReciveTooltip',
	      }).append($('<div />', {
	            class: 'talkReciveContent',
	            text: messageContent
	      }));
	      //프로필 사진
	      var talkReciveProfile = $('<div />',{
	         class: 'talkReciveProfile'
	      }).append($('<img />', {
	            class: 'profileImg',
	            src: '../image/profileimg.png',
	            alt: '프로필이미지',
	            width: '36',
	            height:'36'
	      }));
	      //받은메세지 시간
	      var talkReciveTime = $('<div />',{
	         class: 'talkReciveTime',
	         text: 시간이들어감
	      });

	      //보낸메세지
	      var talkSendDiv =  $('<div />',{
	         class: 'talkSendDiv',
	      });
	      //보낸메세지 말풍선+내용
	      var talkSendTooltip = $('<div />', {
	         class: 'talkSendTooltip'
	      }).append($('<div />', {
	            class: 'talkSendContent',
	            text: messageContent
	   }));
	      //보낸메세지 시간
	      var talkSendTime = $('<div />',{
	         class: 'talkSendTime',
	         text: 시간이들어감
	      });
	      //보낸메세지 읽음 확인
	      var readCheck = $('<div />',{
	         class: 'readCheck',
	         text: '안읽음'
	      });

	      
	      //1. 메세지가 하루 중 처음 온것인지 아닌지

	      //2. 메세지가 보낸건지 받은건지
	      
	      //2-1. 메세지를 보낸거라면 메세지를 읽었는지 안읽었는지
	      
	      //2-2. 메세지를 받은거라면 system시간 기준 1분 사이에 처음 보낸 메세지인지 마지막에 보낸메세지인지
	      
	   }));
	   
	});
   
