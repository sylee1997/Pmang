package talk.service;

public class TalkServiceImple implements TalkService {

}
